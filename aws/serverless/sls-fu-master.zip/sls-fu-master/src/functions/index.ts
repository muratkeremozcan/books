export { default as hello } from './hello';
export { default as people } from './people';
