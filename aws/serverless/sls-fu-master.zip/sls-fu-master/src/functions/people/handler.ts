import { formatJSONResponse } from '@libs/apiGateway';
import { middyfy } from '@libs/lambda';
import * as data from './data/people.json';

const people = async (event) => {
  const timestamp = (new Date()).toISOString();
  console.log("people lambda function!", timestamp, event);
  return formatJSONResponse(data);
}

export const main = middyfy(people);
